try:
    # my code
    pass
except