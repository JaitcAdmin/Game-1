class Sprite:
    def __init__(self, fps):
        self.ItStand = False
        self.end = False
        self.fps = fps

    def move(self):
        pass

    def end(self):
        pass
