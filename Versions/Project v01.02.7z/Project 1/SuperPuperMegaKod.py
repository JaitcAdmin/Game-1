while 1:
    a = int(input())
    b = int(input())
    c = input()
    d = int(input())
    e = int(input())
    res = 0
    res2 = [0, 0]

    if c == "+":
        res = (a / b) + (d / e)
    if c == "-":
        res = (a / b) - (d / e)
    for i in range(1, int(1 / res) + 1):
        for y in range(1, b * e + 1):
            if res + 0.00001 > i / y > res - 0.00001:
                res2[0] = i
                res2[1] = y
                print(i, '/', y)
                print("\n"*5)
    for i in range(1, res2[1]):
        if res2[0] / i == 0 and res2[1] / i == 0:
            print(res2[1], '/', res2[0])
