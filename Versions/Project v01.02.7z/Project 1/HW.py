import random

a = input()

if a == "kvb":
    while 1:
        for i in range(0, int(random.random()*10000)):
            print(random.random())